exports.deliveryTypeToGerman = {
  delivery: "Lieferung",
  pickup: "Abholung",
};

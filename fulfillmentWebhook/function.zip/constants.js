exports.endpoint = process.env.SHOPIFY_ENDPOINT;
